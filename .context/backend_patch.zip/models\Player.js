const mongoose = require('mongoose');

const playerSchema = new mongoose.Schema({
  teamId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Time', 
    index: true,
    required: false // Comentário: explicitamente não obrigatório
  },

  // Saldo normal e congelado (R$)
  saldo: {
    type: Number,
    default: 0,
    min: 0 // Comentário: impede saldo negativo
  },
  saldoCongelado: {
    type: Number,
    default: 0,
    min: 0 // Comentário: impede saldo negativo
  },

  // Crédito acumulativo de aposta
  allowance: {
    type: Number,
    default: 200,
    min: 0 // Comentário: impede crédito negativo
  },
  startOfWeek: {
    type: Date,
    default: null
  }
}, { timestamps: true });

module.exports = mongoose.model('Player', playerSchema);

/*
Principais mudanças:
- Adicionado min: 0 para campos numéricos para evitar valores negativos.
- Comentários padronizados e claros.
- Nenhuma alteração de lógica, apenas melhorias de legibilidade e boas práticas.
*/