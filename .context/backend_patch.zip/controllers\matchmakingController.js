// backend/controllers/matchmakingController.js
const Queue   = require('../models/Queue');
const Match   = require('../models/Match');
const Time    = require('../models/Time');
const Player  = require('../models/Player');
const mongoose = require('mongoose');

// ===== Config =====
const ACCEPT_TIMEOUT_SECS     = Number(process.env.MATCH_ACCEPT_TIMEOUT_SECS) || 60;
const WEEKLY_TOPUP_PER_PLAYER = Number(process.env.WEEKLY_TOPUP_PER_PLAYER)  || 200;

// ===== Helpers básicos =====
const isValidObjectId = (id) => !!id && mongoose.Types.ObjectId.isValid(id);
const toNumber        = (v) => (Number.isFinite(+v) ? +v : NaN);
const idEq            = (a, b) => String(a) === String(b);

// --- Aposta por cabeça (MVP exige inteiro e distribuição exata) ---
function calcPerHead(valorAposta, membersCount) {
  if (!Number.isFinite(valorAposta) || valorAposta < 1) return NaN;
  if (!Number.isInteger(valorAposta)) return NaN;
  if (membersCount < 5) return NaN;                 // força time completo no MVP
  if (valorAposta % membersCount !== 0) return NaN; // sem centavos quebrados
  return valorAposta / membersCount;
}

// ======== Tolerância / faixa ========
function getTolerancePercent(minutes) {
  if (minutes <= 2) return 0.3;
  if (minutes <= 4) return 1.0;
  if (minutes <= 6) return 3.0;
  return 10.0;
}
function rangeByTolerance(valorAposta, tol) {
  const delta = Math.floor(valorAposta * tol);
  const min = Math.max(1, valorAposta - delta);
  const max = valorAposta + delta;
  return { min, max };
}

// ======== Top-up semanal cumulativo (por jogador) ========
// Segunda-feira 00:00:00 UTC da semana de 'd'
function mondayUTC(d = new Date()) {
  const dt = new Date(d);
  const day = dt.getUTCDay(); // 0..6
  const diff = (day + 6) % 7; // volta até segunda
  dt.setUTCHours(0,0,0,0);
  dt.setUTCDate(dt.getUTCDate() - diff);
  return dt;
}
// Semanas inteiras entre dois inícios de semana (>=0)
function weeksBetween(fromMon, toMon) {
  const ms = toMon.getTime() - fromMon.getTime();
  const w  = Math.floor(ms / (7*24*60*60*1000));
  return w > 0 ? w : 0;
}
// Aplica +WEEKLY_TOPUP_PER_PLAYER * (#semanas) e atualiza lastTopUpAt = mondayAtual
async function applyWeeklyTopUpToPlayers(playerIds, session) {
  if (!playerIds?.length) return;

  const players = await Player.find({ _id: { $in: playerIds } })
    .session(session)
    .select('_id saldo lastTopUpAt createdAt')
    .lean();

  if (!players.length) return;

  const nowMonday = mondayUTC(new Date());

  const incOps = [];
  const setOps = [];
  for (const p of players) {
    const last = p.lastTopUpAt ? mondayUTC(new Date(p.lastTopUpAt)) :
                p.createdAt    ? mondayUTC(new Date(p.createdAt))    :
                                 nowMonday; // se nunca, considera semana atual (0 semanas)
    const w = weeksBetween(last, nowMonday);
    if (w > 0) {
      const credit = w * WEEKLY_TOPUP_PER_PLAYER;
      incOps.push({ updateOne: { filter: { _id: p._id }, update: { $inc: { saldo: credit } } } });
      setOps.push({ updateOne: { filter: { _id: p._id }, update: { $set: { lastTopUpAt: nowMonday } } } });
    } else {
      setOps.push({ updateOne: { filter: { _id: p._id }, update: { $set: { lastTopUpAt: p.lastTopUpAt || nowMonday } } } });
    }
  }

  if (incOps.length) await Player.bulkWrite(incOps, { session });
  if (setOps.length) await Player.bulkWrite(setOps, { session });
}

// Helper: obter ids de jogadores do time (membros|players)
async function getTeamPlayerIds(teamId, session) {
  const t = await Time.findById(teamId)
    .session(session)
    .select('membros players')
    .lean();
  if (!t) return [];
  const arr = Array.isArray(t.membros) ? t.membros : Array.isArray(t.players) ? t.players : [];
  return arr.map(x => new mongoose.Types.ObjectId(x));
}

// ======== Endpoints ========

// POST /api/matchmaking/queue  body: { teamId, valorAposta }
exports.enterQueue = async (req, res) => {
  try {
    const { teamId } = req.body;
    let { valorAposta } = req.body;

    if (!isValidObjectId(teamId)) {
      return res.status(400).json({ ok: false, error: 'teamId inválido' });
    }
    valorAposta = toNumber(valorAposta);
    if (!Number.isFinite(valorAposta) || valorAposta < 1) {
      return res.status(400).json({ ok: false, error: 'valorAposta inválido (>= 1)' });
    }

    const oid = new mongoose.Types.ObjectId(teamId);
    const team = await Time.findById(oid).lean();
    if (!team) return res.status(404).json({ ok: false, error: 'Time não encontrado' });

    // Impede enfileirar se já está em partida pendente/em_andamento
    const emMatch = await Match.exists({
      teams: oid,
      $or: [{ status: 'pendente' }, { status: 'em_andamento' }],
    });
    if (emMatch) {
      return res.status(400).json({ ok: false, error: 'Time já está em uma partida' });
    }

    // Upsert idempotente
    const mine = await Queue.findOneAndUpdate(
      { teamId: oid },
      { $set: { valorAposta, byUserId: req.user?._id }, $setOnInsert: { createdAt: new Date() } },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    const createdAt = mine.createdAt || new Date();
    const minutes   = (Date.now() - new Date(createdAt).getTime()) / 60000;
    const tol       = getTolerancePercent(minutes);
    const { min, max } = rangeByTolerance(mine.valorAposta, tol);

    // Busca oponente simples (em memória)
    const candidates = await Queue.find({}).sort({ createdAt: 1 }).limit(100).lean();
    const opponent = candidates.find(c =>
      String(c.teamId) !== String(oid) &&
      Number.isFinite(+c.valorAposta) &&
      c.valorAposta >= min &&
      c.valorAposta <= max
    );

    if (!opponent) {
      return res.status(200).json({
        ok: true, queued: true, teamId: oid.toHexString(),
        valorAposta: mine.valorAposta, tolerance: tol, range: { min, max }
      });
    }

    // Cria partida
    const oppOid = new mongoose.Types.ObjectId(opponent.teamId);
    const menorAposta = Math.min(mine.valorAposta, opponent.valorAposta);
    const match = await Match.create({
      teams: [oid, oppOid],
      valorAposta: menorAposta,
      status: 'pendente',
      createdAt: new Date(),
      acceptDeadline: new Date(Date.now() + ACCEPT_TIMEOUT_SECS * 1000),
    });

    // Remove ambos da fila
    await Promise.all([
      Queue.deleteOne({ teamId: oid }),
      Queue.deleteOne({ teamId: oppOid }),
    ]);

    return res.status(201).json({
      ok: true,
      matched: true,
      matchId: match._id,
      teams: match.teams,
      valorAposta: match.valorAposta,
      status: match.status,
    });
  } catch (err) {
    console.error('enterQueue error:', err);
    return res.status(500).json({ ok: false, error: 'Erro interno' });
  }
};

// POST /api/matchmaking/cancel  body: { teamId }
exports.cancelQueue = async (req, res) => {
  try {
    const { teamId } = req.body;
    if (!isValidObjectId(teamId)) {
      return res.status(400).json({ ok: false, error: 'teamId inválido' });
    }
    const oid = new mongoose.Types.ObjectId(teamId);
    const del = await Queue.deleteOne({ teamId: oid });
    return res.status(200).json({ ok: true, deleted: del.deletedCount });
  } catch (err) {
    console.error('cancelQueue error:', err);
    return res.status(500).json({ ok: false, error: 'Erro interno' });
  }
};

// GET /api/matchmaking/status?teamId=...
exports.status = async (req, res) => {
  try {
    let { teamId } = req.query;
    teamId = String(teamId || '').trim();

    if (!isValidObjectId(teamId)) {
      return res.status(400).json({ ok: false, error: 'teamId inválido' });
    }

    const oid = new mongoose.Types.ObjectId(teamId);
    console.log('[status] teamId(raw)=', teamId, ' oid=', oid.toHexString());

    // 1) partida ativa
    const match = await Match.findOne({
      teams: oid,
      $or: [{ status: 'pendente' }, { status: 'em_andamento' }],
    }).sort({ createdAt: -1 }).lean();

    console.log('[status] match?', !!match);

    if (match) {
      return res.status(200).json({
        ok: true,
        matched: true,
        matchId: String(match._id),
        status: match.status,
        teams: Array.isArray(match.teams) ? match.teams.map(String) : [],
        valorAposta: match.valorAposta,
        perHead: match.perHead ?? null, // expõe per-head quando houver
        startedAt: match.startedAt ?? null,
        finishedAt: match.finishedAt ?? null,
        acceptedBy: Array.isArray(match.acceptedBy) ? match.acceptedBy.map(String) : [],
        winnerTeamId: match.winnerTeamId ? String(match.winnerTeamId) : null,
        acceptDeadline: match.acceptDeadline ?? null,
        cancelReason: match.cancelReason ?? null,
      });
    }

    // 2) fila
    const q = await Queue.findOne({ teamId: oid }).lean();
    console.log('[status] queue?', !!q);

    if (q) {
      const createdAt = q.createdAt instanceof Date ? q.createdAt : new Date(q.createdAt || Date.now());
      const minutes = (Date.now() - createdAt.getTime()) / 60000;
      const tol = getTolerancePercent(minutes);
      const { min, max } = rangeByTolerance(q.valorAposta, tol);

      return res.status(200).json({
        ok: true,
        queued: true,
        teamId: oid.toHexString(),
        valorAposta: q.valorAposta,
        tolerance: tol,
        range: { min, max },
      });
    }

    // 3) nada
    return res.status(200).json({ ok: true, queued: false, matched: false });
  } catch (err) {
    console.error('status error:', err);
    return res.status(500).json({ ok: false, error: 'Erro interno' });
  }
};

// ===================== Ciclo da partida =====================

// POST /api/matchmaking/accept  body: { matchId, teamId }
exports.accept = async (req, res) => {
  try {
    const { matchId, teamId } = req.body;

    if (!isValidObjectId(matchId) || !isValidObjectId(teamId)) {
      return res.status(400).json({ ok: false, error: 'matchId e teamId válidos são obrigatórios' });
    }

    const match = await Match.findOne({
      _id: matchId,
      teams: teamId,
      $or: [{ status: 'pendente' }, { status: 'em_andamento' }],
    });
    if (!match) {
      return res.status(404).json({ ok: false, error: 'Partida não encontrada ou inválida para aceitar' });
    }

    // Timeout de aceite
    if (match.status === 'pendente' && match.acceptDeadline && Date.now() > new Date(match.acceptDeadline).getTime()) {
      match.status = 'cancelada';
      match.cancelReason = 'timeout';
      match.finishedAt = new Date();
      await match.save();

      // reenfileira ambos
      await Promise.all(
        match.teams.map((tid) =>
          Queue.findOneAndUpdate(
            { teamId: tid },
            { $set: { valorAposta: match.valorAposta }, $setOnInsert: { createdAt: new Date() } },
            { upsert: true, setDefaultsOnInsert: true }
          )
        )
      );

      return res.status(409).json({
        ok: false, canceled: true, error: 'match timeout',
        matchId: match._id, cancelReason: match.cancelReason,
      });
    }

    // marca aceite idempotente
    if (!Array.isArray(match.acceptedBy)) match.acceptedBy = [];
    if (!match.acceptedBy.some(t => idEq(t, teamId))) {
      match.acceptedBy.push(teamId);
    }

    const ambosAceitaram = match.teams.every(t => match.acceptedBy.some(a => idEq(a, t)));

    if (ambosAceitaram && match.status === 'pendente') {
      const session = await mongoose.startSession();
      try {
        await session.withTransaction(async () => {
          const aposta = match.valorAposta;

          // times
          const teamOids = match.teams.map(t => new mongoose.Types.ObjectId(t));
          const [tA, tB] = teamOids;

          // pega jogadores
          const [pAIds, pBIds] = await Promise.all([
            getTeamPlayerIds(tA, session),
            getTeamPlayerIds(tB, session),
          ]);

          const bothHavePlayers = pAIds.length > 0 && pBIds.length > 0;

          if (bothHavePlayers) {
            // top-up semanal acumulado
            await applyWeeklyTopUpToPlayers([...pAIds, ...pBIds], session);

            // per-head (exige times com mesmo tamanho no MVP)
            const shareA = aposta / pAIds.length;
            const shareB = aposta / pBIds.length;
            if (!Number.isFinite(shareA) || !Number.isFinite(shareB)) {
              const e = new Error('aposta_incompativel'); e.code = 'BAD_PER_HEAD'; throw e;
            }
            if (Math.abs(shareA - shareB) > 0) {
              const e = new Error('times_com_tamanhos_diferentes'); e.code = 'BAD_SIZE'; throw e;
            }

            // checa saldo de cada jogador (pós top-up)
            const playersA = await Player.find({ _id: { $in: pAIds } })
              .session(session).select('_id saldo').lean();
            const playersB = await Player.find({ _id: { $in: pBIds } })
              .session(session).select('_id saldo').lean();

            const insufA = playersA.find(p => (p.saldo ?? 0) < shareA);
            const insufB = playersB.find(p => (p.saldo ?? 0) < shareB);
            if (insufA || insufB) {
              const e = new Error('saldo_insuficiente_jogador'); e.code = 'SALDO_PLAYER';
              e.data = { who: insufA ? 'timeA' : 'timeB', id: (insufA?._id || insufB?._id || '').toString() };
              throw e;
            }

            // congela por jogador (debita saldo e aumenta saldoCongelado)
            const ops = [];
            for (const id of pAIds) {
              ops.push({ updateOne: { filter: { _id: id }, update: { $inc: { saldo: -shareA, saldoCongelado: +shareA } } } });
            }
            for (const id of pBIds) {
              ops.push({ updateOne: { filter: { _id: id }, update: { $inc: { saldo: -shareB, saldoCongelado: +shareB } } } });
            }
            if (ops.length) await Player.bulkWrite(ops, { session });

            // snapshot por jogador
            match.$session(session);
            match.status = 'em_andamento';
            match.startedAt = new Date();
            match.acceptDeadline = null;
            match.perHead = shareA;               // shareA == shareB no MVP
            match.teamAPlayers = pAIds;
            match.teamBPlayers = pBIds;
            await match.save({ session });

          } else {
            // fallback por TIME (mantém compatibilidade)
            const teamsDocs = await Time.find({ $or: [{ _id: tA }, { _id: tB }] })
              .session(session).select('_id saldo saldoCongelado').lean();
            if (teamsDocs.length !== 2) {
              const err = new Error('times_nao_encontrados');
              err.code = 'NOT_FOUND'; throw err;
            }
            const insuf = teamsDocs.find(t => (t.saldo ?? 0) < aposta);
            if (insuf) {
              const err = new Error('saldo_insuficiente');
              err.code = 'SALDO'; throw err;
            }

            await Promise.all(
              [tA, tB].map(_id =>
                Time.updateOne({ _id }, { $inc: { saldo: -aposta, saldoCongelado: +aposta } }, { session })
              )
            );

            match.$session(session);
            match.status = 'em_andamento';
            match.startedAt = new Date();
            match.acceptDeadline = null;
            await match.save({ session });
          }
        });
      } catch (e) {
        await session.endSession();
        if (e?.code === 'SALDO_PLAYER') {
          return res.status(400).json({ ok: false, error: 'saldo_insuficiente_jogador', details: e.data, matchId: match._id });
        }
        if (e?.code === 'BAD_PER_HEAD') {
          return res.status(400).json({ ok:false, error:'valorAposta_incompativel_com_tamanho_do_time', matchId: match._id });
        }
        if (e?.code === 'BAD_SIZE') {
          return res.status(400).json({ ok:false, error:'times_com_tamanhos_diferentes', matchId: match._id });
        }
        if (e?.code === 'SALDO') {
          return res.status(400).json({ ok: false, error: 'saldo_insuficiente', matchId: match._id });
        }
        if (e?.code === 'NOT_FOUND') {
          return res.status(404).json({ ok: false, error: 'times_nao_encontrados', matchId: match._id });
        }
        console.error('accept tx error:', e);
        return res.status(500).json({ ok: false, error: 'Erro ao iniciar partida' });
      }
      await session.endSession();

      return res.status(200).json({
        ok: true,
        matchId: match._id,
        status: match.status,
        acceptedBy: match.acceptedBy,
        teams: match.teams,
        startedAt: match.startedAt ?? null,
      });
    }

    // ainda não são os dois
    await match.save();
    return res.status(200).json({
      ok: true,
      matchId: match._id,
      status: match.status,
      acceptedBy: match.acceptedBy,
      teams: match.teams,
      startedAt: match.startedAt ?? null,
    });
  } catch (err) {
    console.error('accept error:', err);
    return res.status(500).json({ ok: false, error: 'Erro interno' });
  }
};

// POST /api/matchmaking/finish  body: { matchId, winnerTeamId, placar? }
exports.finish = async (req, res) => {
  try {
    const { matchId, winnerTeamId, placar } = req.body;

    if (!isValidObjectId(matchId) || !isValidObjectId(winnerTeamId)) {
      return res.status(400).json({ ok: false, error: 'matchId e winnerTeamId válidos são obrigatórios' });
    }

    let match = await Match.findById(matchId);
    if (!match) return res.status(404).json({ ok: false, error: 'Partida não encontrada' });

    if (!match.teams.some(t => idEq(t, winnerTeamId))) {
      return res.status(400).json({ ok: false, error: 'winnerTeamId não pertence à partida' });
    }

    // Idempotência
    if (match.status === 'finalizada' || match.status === 'finalizado') {
      return res.status(200).json({
        ok: true,
        alreadyFinished: true,
        matchId: match._id,
        status: match.status,
        winnerTeamId: match.winnerTeamId ?? null,
        placar: match.placar ?? null,
        finishedAt: match.finishedAt ?? match.endedAt ?? null,
      });
    }
    if (match.status === 'pendente') {
      return res.status(409).json({ ok: false, error: 'Partida ainda não começou (pendente)' });
    }
    if (match.status === 'cancelada') {
      return res.status(409).json({ ok: false, error: 'Partida cancelada' });
    }

    const session = await mongoose.startSession();
    try {
      await session.withTransaction(async () => {
        match = await Match.findById(matchId).session(session);
        if (!match) throw new Error('match_nao_encontrada_tx');

        if (match.status === 'finalizada' || match.status === 'finalizado') return;

        const perHead = Number(match.perHead || 0);

        // ---- liquidação por JOGADOR (se houver snapshot) ----
        if (
          perHead > 0 &&
          Array.isArray(match.teamAPlayers) && Array.isArray(match.teamBPlayers) &&
          match.teamAPlayers.length && match.teamBPlayers.length
        ) {
          const A = match.teamAPlayers.map(id => new mongoose.Types.ObjectId(id));
          const B = match.teamBPlayers.map(id => new mongoose.Types.ObjectId(id));
          const all = [...A, ...B];

          // sanity: todos têm congelado suficiente
          const players = await Player.find({ _id: { $in: all } })
            .session(session).select('_id saldoCongelado').lean();
          const byId = new Map(players.map(p => [String(p._id), p]));
          const bad = all.find(id => ((byId.get(String(id))?.saldoCongelado ?? 0) < perHead));
          if (bad) { const err = new Error('congelado_insuficiente_player'); err.code='SALDO_CONGELADO_PLAYER'; throw err; }

          // 1) descongela perHead de TODOS
          const ops = all.map(id => ({
            updateOne: { filter: { _id: id }, update: { $inc: { saldoCongelado: -perHead } } }
          }));

          // 2) credita vencedores +2*perHead
          const winnerIsA = String(winnerTeamId) === String(match.teams[0]);
          const winners = winnerIsA ? A : B;
          for (const id of winners) {
            ops.push({ updateOne: { filter: { _id: id }, update: { $inc: { saldo: 2 * perHead } } } });
          }

          if (ops.length) await Player.bulkWrite(ops, { session });

        } else {
          // ---- fallback por TIME (compatibilidade) ----
          const aposta = match.valorAposta;
          const [tA, tB] = match.teams.map(t => new mongoose.Types.ObjectId(t));
          const winnerOid = new mongoose.Types.ObjectId(winnerTeamId);

          const teamsDocs = await Time.find({ $or: [{ _id: tA }, { _id: tB }] })
            .session(session).select('_id saldoCongelado').lean();
          if (teamsDocs.length !== 2) {
            const err = new Error('times_nao_encontrados'); err.code = 'NOT_FOUND'; throw err;
          }
          const insufCong = teamsDocs.find(t => (t.saldoCongelado ?? 0) < aposta);
          if (insufCong) {
            const err = new Error('congelado_insuficiente'); err.code = 'SALDO_CONGELADO'; throw err;
          }

          await Promise.all([
            Time.updateOne({ _id: tA }, { $inc: { saldoCongelado: -aposta } }, { session }),
            Time.updateOne({ _id: tB }, { $inc: { saldoCongelado: -aposta } }, { session }),
            Time.updateOne({ _id: winnerOid }, { $inc: { saldo: 2 * aposta } }, { session }),
          ]);
        }

        // finalizar partida
        match.$session(session);
        match.status = 'finalizada';
        match.winnerTeamId = winnerTeamId;
        if (placar) match.placar = placar;
        match.finishedAt = new Date();
        await match.save({ session });
      });
    } catch (e) {
      await session.endSession();
      if (e?.code === 'SALDO_CONGELADO_PLAYER') {
        return res.status(400).json({ ok:false, error:'saldo_congelado_insuficiente_player', matchId });
      }
      if (e?.code === 'SALDO_CONGELADO') {
        return res.status(400).json({ ok: false, error: 'saldo_congelado_insuficiente', matchId });
      }
      if (e?.code === 'NOT_FOUND') {
        return res.status(404).json({ ok: false, error: 'times_nao_encontrados', matchId });
      }
      console.error('finish tx error:', e);
      return res.status(500).json({ ok: false, error: 'Erro ao finalizar partida' });
    }
    await session.endSession();

    return res.status(200).json({
      ok: true,
      matchId: match._id,
      status: match.status,
      winnerTeamId: match.winnerTeamId,
      placar: match.placar ?? null,
      finishedAt: match.finishedAt ?? null,
    });
  } catch (err) {
    console.error('finish error:', err);
    return res.status(500).json({ ok: false, error: 'Erro interno' });
  }
};
