// server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');

// 🔒 Segurança leve e segura
const mongoose = require('mongoose');                 // NEW
const mongoSanitize = require('express-mongo-sanitize'); // NEW

// 🔌 Conexão com o MongoDB
const conectarMongo = require('./config/db');

// 🔔 NEW: agendador da varredura de timeouts
const { scheduleMatchTimeoutSweep } = require('./jobs/matchTimeoutSweep');

// 🛣️ Rotas
const authRoutes = require('./rotas/authRoutes');
const teamRoutes = require('./rotas/teamroutes');
const matchmakingRoutes = require('./rotas/matchmakingRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// ===== Segurança Mongoose (não muda comportamento do app) =====
mongoose.set('strictQuery', true);
mongoose.set('sanitizeFilter', true);
mongoose.set('sanitizeProjection', true);

// Middlewares
app.use(cors());
app.use(express.json());
app.use(mongoSanitize()); // remove operadores $ e chaves com ponto dos payloads

// 🔎 Healthcheck
app.get('/health', (_req, res) => res.status(200).json({ ok: true }));

// Rota raiz
app.get('/', (_req, res) => {
  res.send('Servidor do RiftPlay está rodando com sucesso!');
});

// Rotas
app.use('/api', authRoutes);
app.use('/api/team', teamRoutes);
app.use('/api/matchmaking', matchmakingRoutes);

// 👉 Sobe o HTTP primeiro
const server = app.listen(PORT, () => {
  console.log(`🟢 Servidor rodando em: http://localhost:${PORT}`);
});

// 👉 Conecta no Mongo e, se ok, inicia o sweep de timeout
(async () => {
  try {
    await conectarMongo();
    console.log('✅ MongoDB conectado com sucesso!');
    scheduleMatchTimeoutSweep(); // NEW
  } catch (err) {
    console.error('❌ Erro ao conectar ao MongoDB:', err?.message || err);
    // process.exit(1);
  }
})();

// (opcional) logs de erros não tratados
process.on('unhandledRejection', (reason) => console.error('⚠️ UnhandledRejection:', reason));
process.on('uncaughtException', (err) => console.error('⚠️ UncaughtException:', err));

module.exports = { app, server };
