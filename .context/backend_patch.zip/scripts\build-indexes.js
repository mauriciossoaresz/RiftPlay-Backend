// scripts/build-indexes.js
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const conectarMongo = require('../config/db');
const mongoose = require('mongoose');

(async () => {
  try {
    await conectarMongo();

    // Importa modelos DEPOIS da conexão
    const Match = require('../models/Match');
    const Queue = require('../models/Queue');

    // Helper: cria índice e ignora conflito de nome/opções (code 85 ou 48)
    async function ensureIndex(collection, spec, options = {}) {
      try {
        await collection.createIndex(spec, options);
        console.log('✓ Index OK:', { spec, options });
      } catch (e) {
        if (e?.code === 85 || e?.code === 48) {
          console.log('• Index já existia (nome/opção diferente):', { spec, options });
        } else {
          throw e;
        }
      }
    }

    // ===== Queue =====
    await ensureIndex(Queue.collection, { teamId: 1 }, { unique: true, name: 'teamId_unique' });
    await ensureIndex(Queue.collection, { createdAt: 1 }, { name: 'queue_createdAt_1' });

    // ===== Match =====
    await ensureIndex(Match.collection, { status: 1, acceptDeadline: 1 }, { name: 'status_acceptDeadline_1' });
    await ensureIndex(Match.collection, { teams: 1, createdAt: 1 }, { name: 'teams_createdAt_1' });
    await ensureIndex(Match.collection, { createdAt: 1 }, { name: 'match_createdAt_1' });

    // Mostra o estado final
    console.log('\nÍndices de Queue:', await Queue.collection.indexes());
    console.log('\nÍndices de Match:', await Match.collection.indexes());

    await mongoose.disconnect();
    process.exit(0);
  } catch (e) {
    console.error('Erro ao criar índices:', e);
    process.exit(1);
  }
})();
