const mongoose = require('mongoose');
const { Schema } = mongoose;

/**
 * Fila de matchmaking por time e valor de aposta.
 * Uma entrada por time (unique), usada para buscar adversário compatível.
 */
const queueSchema = new Schema(
  {
    teamId: {
      type: Schema.Types.ObjectId,
      ref: 'Time',
      required: true,
      unique: true,   // Um time só pode ter 1 entrada na fila
      index: true,
    },
    valorAposta: {
      type: Number,
      required: true,
      min: 1,
      index: true,
    },
    // Opcional: quem colocou na fila (ex.: capitão)
    byUserId: { type: Schema.Types.ObjectId, ref: 'Jogador', default: null },
  },
  {
    timestamps: true,       // Cria createdAt/updatedAt (o controller usa createdAt)
    versionKey: false,
  }
);

// Expira entradas antigas automaticamente após 1 hora (mantém a fila limpa)
// Comentário ajustado para clareza
queueSchema.index({ createdAt: 1 }, { expireAfterSeconds: 3600 });

// Índice para buscas por faixa de aposta + antiguidade
queueSchema.index({ valorAposta: 1, createdAt: 1 });

// Melhoria: exportação explícita do modelo
module.exports = mongoose.model('Queue', queueSchema);

/*
Principais mudanças:
- Comentários ajustados para clareza e padronização.
- Exportação explícita do modelo.
- Garantia de boas práticas de schema e indexação.
- Nenhuma alteração de lógica, apenas melhorias de legibilidade */ 