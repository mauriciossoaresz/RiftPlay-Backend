const mongoose = require('mongoose');
const { Schema, Types } = mongoose;

const matchSchema = new Schema(
  {
    // Sempre 2 IDs de times
    teams: [
      { type: Types.ObjectId, ref: 'Time', required: true }
    ],

    // Aposta usada no pareamento
    valorAposta: { type: Number, required: true, min: 1 },

    // Ciclo da partida
    status: {
      type: String,
      enum: ['pendente', 'em_andamento', 'finalizada', 'cancelada'],
      default: 'pendente',
      index: true,
    },
     perHead: { type: Number, required: false, default: 0 }, // valor por jogador

     teamAPlayers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Player' }],
      teamBPlayers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Player' }],

    // /accept: quem já aceitou
    acceptedBy: [{ type: Types.ObjectId, ref: 'Time', default: [] }],

    // (Opcional) quem já teve saldo reservado/congelado
    reservedBy: [{ type: Types.ObjectId, ref: 'Time', default: [] }],

    // Aceite + cancelamento
    acceptDeadline: { type: Date, default: null },
    cancelReason:   { type: String, default: null },

    // Timestamps do ciclo
    startedAt:  { type: Date, default: null },
    finishedAt: { type: Date, default: null },

    // Resultado
    winnerTeamId: { type: Types.ObjectId, ref: 'Time', default: null },

    // Placar flexível: string ("13-9") ou objeto ({ a:13, b:9 })
    placar: { type: Schema.Types.Mixed, default: null },
  },
  { timestamps: true }
);

// Validação: exatamente 2 times
matchSchema.path('teams').validate(
  (arr) => Array.isArray(arr) && arr.length === 2,
  'A partida deve conter exatamente 2 times.'
);

// Índices úteis para performance em consultas
matchSchema.index({ status: 1, createdAt: 1 });
matchSchema.index({ status: 1, acceptDeadline: 1 });
matchSchema.index({ teams: 1, status: 1 });

// Exportação explícita do modelo
module.exports = mongoose.model('Match', matchSchema);

/*
Principais mudanças:
- Comentários padronizados e mais claros.
- Garantia de validação robusta para o campo teams.
- Exportação explícita do modelo.
- Organização dos índices para consultas mais rápidas.
- Nenhuma alteração de lógica, apenas melhorias de legibilidade e boas práticas.
*/